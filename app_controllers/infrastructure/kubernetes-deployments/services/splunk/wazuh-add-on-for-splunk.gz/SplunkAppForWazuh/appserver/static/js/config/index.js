define([
  './routes/overview-states',
  './routes/settings-states',
  './routes/management-states',
  './routes/agents-states'
], function() {})
