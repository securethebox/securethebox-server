define([
  './main/settingsCtrl',
  './index/settingsIndexCtrl',
  './api/settingsApiCtrl',
  './extensions/extensionsCtrl',
  './logs/logsCtrl',
  './about/aboutCtrl'
], function() {})
